from v import call 


newFun = call.account('frank', 54, 6)
print (newFun.name)
