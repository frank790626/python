# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 21:07:17 2016

@author: frank
"""

from distutils.core import setup

setup(
    name = 'HelloPY',
    packages = ['main', 'ne1', 'v'],
    scripts = [],
    version = '1.0',
    description = 'My first project',
    author = 'frank',
    author_email = 'frank@gmail.com',
    url = 'https://github.com/frank790626/python',
    download_url = 'https://github.com/frank790626/python/tarball/v1.0',
    keywords = ['Good Project'],
)