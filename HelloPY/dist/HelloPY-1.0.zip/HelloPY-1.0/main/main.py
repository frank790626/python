#unicoding utf-8
import sys
sys.path.append("D:\document\github\python\HelloPY")
from v import call 

newFun = call.account('frank', 54, 6)
print (newFun.name)